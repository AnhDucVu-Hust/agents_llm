# Copy and paste your OpenAI API Key
openai_base_url = "https://openrouter.ai/api/v1"
openai_api_key = "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"
openai_embedding_key = "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"
# Put your name
key_owner = "ducva4"

maze_assets_loc = "../../environment/frontend_server/static_dirs/assets"
env_matrix = f"{maze_assets_loc}/the_ville/matrix"
env_visuals = f"{maze_assets_loc}/the_ville/visuals"

fs_storage = "../../environment/frontend_server/storage"
fs_temp_storage = "../../environment/frontend_server/temp_storage"

collision_block_id = "32125"

# Verbose 
debug = True

wake_up_hour_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 5, 
             "temperature": 0.8, "top_p": 1, "stream": False,
             "frequency_penalty": 0, "presence_penalty": 0, "stop": ["\n"]}

daily_plan_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 300, 
               "temperature": 0.4, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": ["\n\n"]}
hourly_schedule_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 300, 
             "temperature": 0, "top_p": 1, "stream": False,
             "frequency_penalty": 0, "presence_penalty": 0, "stop":["["] }
task_decomp_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 1000, 
             "temperature": 0, "top_p": 1, "stream": False,
             "frequency_penalty": 0, "presence_penalty": 0, "stop": ["---"]}
action_sector_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

action_arena_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

action_game_object_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
pronunciatio_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

event_triple_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 30, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": ["\n"]}
#ChatGPT
act_obj_desc_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

act_obj_event_triple_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 30, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": ["\n"]}

new_decomp_schedule_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 1000, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

decide_to_talk_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 20, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

decide_to_react_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 20, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

create_conversation_param = {"engine": "cohere/command-r", "max_tokens": 1000, 
               "temperature": 0.7, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
summarize_conversation_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

extract_keywords_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 50, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

keyword_to_thoughts_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 40, 
               "temperature": 0.7, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

convo_to_thoughts_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 40, 
               "temperature": 0.7, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
event_poignancy_param = {"engine": "nvidia/llama-3.1-nemotron-70b-instruct", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
thought_poignancy_param = {"engine": "nvidia/llama-3.1-nemotron-70b-instruct", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
chat_poignancy_param = {"engine": "nvidia/llama-3.1-nemotron-70b-instruct", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
focal_pt_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

insight_and_guidance_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 150, 
               "temperature": 0.5, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
chat_summarize_ideas_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
agent_chat_summarize_relationship_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
agent_chat_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
summarize_ideas_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

generate_next_convo_line_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 250, 
               "temperature": 1, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

generate_whisper_inner_thought_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 50, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}

planning_thought_on_convo_param = {"engine": "qwen/qwq-32b-preview", "max_tokens": 50, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
memo_on_convo_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 15, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
generate_safety_score_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 50, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}
#ChatGPT
generate_iterative_chat_utt_param = {"engine": "deepseek/deepseek-chat", "max_tokens": 50, 
               "temperature": 0, "top_p": 1, "stream": False,
               "frequency_penalty": 0, "presence_penalty": 0, "stop": None}